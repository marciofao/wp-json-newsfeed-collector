# wp-json-newsfeed-collector
A plugin to fetch articles from another wordpress instance
