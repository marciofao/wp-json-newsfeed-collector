<?php 

/**
 * Plugin Name: Newsfeed Collector
 * Description: Collects newsfeed from various sources and displays them on the website.
 * Version: 1.0
 * Author: Marcio Fão
 * License: GPL2
 * Author uri: https://marciofao.github.io/
 */

 require_once('news-collector-options-page.php');
 require_once('news-collector.php');
 require_once('fetch-tags-and-categs.php');