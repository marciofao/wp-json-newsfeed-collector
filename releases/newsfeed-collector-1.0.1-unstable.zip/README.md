# wp-json-newsfeed-collector
A plugin to fetch articles from another wordpress instance

## Installation
Upload the plugin folder to the /wp-content/plugins/ directory or via the admin interface.

## Release Notes
### 1.0 - Fetch articles from another wordpress instance but no image attachments, it stores the relative url of the attachment image on postmeta
### 1.1 (unstable for some themes) - Fetch articles from another wordpress instance and store the image attachments in media folder
