# wp-json-newsfeed-collector
A plugin to fetch articles from another wordpress instance

## Installation
Upload the plugin folder to the /wp-content/plugins/ directory or via the admin interface.

## Release Notes
### 1.0 (lite) - Very lightweight. Fetch articles from another wordpress instance but no image attachments, it stores the original url of the attachment image on postmeta. Single post template can be customized to use the original url of the image from postmeta.
### 1.1 - Added support for image attachments

Release packages are available on the releases folder
